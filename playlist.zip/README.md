# Playlist (Chrome-like)

## What it does

Show audible tabs and provide play/pause function
